# Cobblemon Vidya Cry Soundpack
# Icon by Eiko! Eiko is the best!

The sounds in this pack are sampled from the games and compiled from Showdown

CHANGELOG FOR 1.1:
	-Added sounds for Gen 8 and 9 Pokemon
	-Prep work for form cries (not implemented into the mod yet)

Pokémon is the property of Nintendo, Creatures Inc., and Game Freak.
Assets included are distributed with the intention of criticism and entertainment as protected by Section 107 of the Copyright Act.
The rights to the property are reserved by ©2022 Pokémon. ©1995 - 2022 Nintendo/Creatures Inc./GAME FREAK inc. TM, and ®Nintendo.