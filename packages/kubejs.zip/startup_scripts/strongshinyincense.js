StartupEvents.registry('item', e => {
  e.create('strongshinyincense').displayName('Strong Shiny Incense').texture('items:item/strongshinyincense').unstackable()
})

