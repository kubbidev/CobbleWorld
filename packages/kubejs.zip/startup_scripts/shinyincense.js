StartupEvents.registry('item', e => {
  e.create('shinyincense').displayName('Shiny Incense').texture('items:item/shinyincense').unstackable()
})

