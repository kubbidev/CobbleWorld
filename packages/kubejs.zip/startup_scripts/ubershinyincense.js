StartupEvents.registry('item', e => {
  e.create('ubershinyincense').displayName('Uber Shiny Incense').texture('items:item/ubershinyincense').unstackable()
})

