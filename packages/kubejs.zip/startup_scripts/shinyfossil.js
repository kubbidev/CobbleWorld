StartupEvents.registry('item', event => { 
  event.create('shinyfossil').displayName('Shiny Fossil').texture('items:item/shinyfossil').unstackable()
})