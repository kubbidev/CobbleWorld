StartupEvents.registry('item', e => {
  e.create('hafossil').displayName('HA fossil').texture('items:item/hafossil').unstackable()
})

